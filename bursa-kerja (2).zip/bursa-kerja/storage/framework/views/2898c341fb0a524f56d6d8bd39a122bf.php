<!DOCTYPE html>
<html>
<head>
    <title>Data Pekerjaan</title>
</head>
<body>
    <h1>Data Pekerjaan</h1>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <a href="<?php echo e(route('pekerjaan.create')); ?>">Tambah Pekerjaan</a>

    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr>
            <th>ID</th>
            <th>Pemberi Kerja</th>
            <th>Keahlian Dibutuhkan</th>
            <th>Deskripsi</th>
            <th>Upah</th>
            <th>Lokasi</th>
            <th>Tanggal Pengerjaan</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->id_pekerjaan); ?></td>
            <td><?php echo e($p->pemberiKerja->nama ?? '-'); ?></td>
            <td><?php echo e($p->keahlian->nama_keahlian ?? '-'); ?></td>
            <td><?php echo e($p->deskripsi); ?></td>
            <td><?php echo e($p->upah); ?></td>
            <td><?php echo e($p->lokasi); ?></td>
            <td><?php echo e($p->tanggal_pengerjaan); ?></td>
            <td><?php echo e($p->status_pekerjaan); ?></td>
            <td>
                <a href="<?php echo e(route('pekerjaan.edit', $p->id_pekerjaan)); ?>">Edit</a>
                <form action="<?php echo e(route('pekerjaan.destroy', $p->id_pekerjaan)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/pekerjaan/index.blade.php ENDPATH**/ ?>