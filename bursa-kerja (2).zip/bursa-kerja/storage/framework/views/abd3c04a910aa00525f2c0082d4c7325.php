<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pekerjaan</title>
</head>
<body>
    <h1>Tambah Pekerjaan</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pekerjaan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Pemberi Kerja:</label><br>
        <select name="id_pemberi">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $pemberiKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pk->id_pemberi); ?>" <?php echo e(old('id_pemberi') == $pk->id_pemberi ? 'selected' : ''); ?>><?php echo e($pk->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label>Keahlian Dibutuhkan:</label><br>
        <select name="id_keahlian">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $keahlian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id_keahlian); ?>" <?php echo e(old('id_keahlian') == $k->id_keahlian ? 'selected' : ''); ?>><?php echo e($k->nama_keahlian); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label>Deskripsi:</label><br>
        <textarea name="deskripsi"><?php echo e(old('deskripsi')); ?></textarea><br><br>

        <label>Upah (Rp):</label><br>
        <input type="number" step="0.01" name="upah" value="<?php echo e(old('upah')); ?>"><br><br>

        <label>Lokasi:</label><br>
        <textarea name="lokasi"><?php echo e(old('lokasi')); ?></textarea><br><br>

        <label>Latitude:</label><br>
        <input type="text" name="latitude" value="<?php echo e(old('latitude')); ?>" placeholder="contoh: -7.28167"><br><br>

        <label>Longitude:</label><br>
        <input type="text" name="longitude" value="<?php echo e(old('longitude')); ?>" placeholder="contoh: 112.7383"><br><br>

        <label>Tanggal Pengerjaan:</label><br>
        <input type="date" name="tanggal_pengerjaan" value="<?php echo e(old('tanggal_pengerjaan')); ?>"><br><br>

        <label>Status Pekerjaan:</label><br>
        <select name="status_pekerjaan">
            <option value="tersedia" <?php echo e(old('status_pekerjaan') == 'tersedia' ? 'selected' : ''); ?>>Tersedia</option>
            <option value="sedang_dikerjakan" <?php echo e(old('status_pekerjaan') == 'sedang_dikerjakan' ? 'selected' : ''); ?>>Sedang Dikerjakan</option>
            <option value="selesai" <?php echo e(old('status_pekerjaan') == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
        </select><br><br>

        <label>Tanggal Posting:</label><br>
        <input type="date" name="tanggal_posting" value="<?php echo e(old('tanggal_posting')); ?>"><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('pekerjaan.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/pekerjaan/create.blade.php ENDPATH**/ ?>