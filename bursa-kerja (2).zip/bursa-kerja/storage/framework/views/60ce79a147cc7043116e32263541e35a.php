<!DOCTYPE html>
<html>
<head><title>Tambah Rating</title></head>
<body>
    <h1>Tambah Rating</h1>
    <?php if($errors->any()): ?><div style="color: red;"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <form action="<?php echo e(route('rating.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Lamaran:</label><br>
        <select name="id_lamaran">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($l->id_lamaran); ?>" <?php echo e(old('id_lamaran') == $l->id_lamaran ? 'selected' : ''); ?>>Lamaran #<?php echo e($l->id_lamaran); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Arah Rating:</label><br>
        <select name="arah_rating">
            <option value="pekerja_ke_pemberi" <?php echo e(old('arah_rating') == 'pekerja_ke_pemberi' ? 'selected' : ''); ?>>Pekerja ke Pemberi</option>
            <option value="pemberi_ke_pekerja" <?php echo e(old('arah_rating') == 'pemberi_ke_pekerja' ? 'selected' : ''); ?>>Pemberi ke Pekerja</option>
        </select><br><br>
        <label>ID Pemberi Rating:</label><br>
        <input type="number" name="pemberi_rating" value="<?php echo e(old('pemberi_rating')); ?>"><br><br>
        <label>ID Penerima Rating:</label><br>
        <input type="number" name="penerima_rating" value="<?php echo e(old('penerima_rating')); ?>"><br><br>
        <label>Skor (1-5):</label><br>
        <input type="number" name="skor" min="1" max="5" value="<?php echo e(old('skor')); ?>"><br><br>
        <label>Kategori Komentar:</label><br>
        <input type="text" name="kategori_komentar" value="<?php echo e(old('kategori_komentar')); ?>" placeholder="contoh: telat bayar"><br><br>
        <label>Tanggal Rating:</label><br>
        <input type="date" name="tanggal_rating" value="<?php echo e(old('tanggal_rating')); ?>"><br><br>
        <button type="submit">Simpan</button>
    </form>
    <br><a href="<?php echo e(route('rating.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/rating/create.blade.php ENDPATH**/ ?>