<!DOCTYPE html>
<html>
<head><title>Data Bukti Penyelesaian</title></head>
<body>
    <h1>Data Bukti Penyelesaian</h1>
    <?php if(session('success')): ?><p style="color: green;"><?php echo e(session('success')); ?></p><?php endif; ?>
    <a href="<?php echo e(route('bukti_penyelesaian.create')); ?>">Tambah Bukti Penyelesaian</a>
    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr><th>ID</th><th>Lamaran</th><th>Foto Bukti Kerja</th><th>Foto Bukti Bayar</th><th>Catatan</th><th>Tanggal Upload</th><th>Aksi</th></tr>
        <?php $__currentLoopData = $buktiPenyelesaian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($b->id_bukti); ?></td>
            <td><?php echo e($b->id_lamaran); ?></td>
            <td><?php echo e($b->foto_bukti_kerja); ?></td>
            <td><?php echo e($b->foto_bukti_bayar); ?></td>
            <td><?php echo e($b->catatan); ?></td>
            <td><?php echo e($b->tanggal_upload); ?></td>
            <td>
                <a href="<?php echo e(route('bukti_penyelesaian.edit', $b->id_bukti)); ?>">Edit</a>
                <form action="<?php echo e(route('bukti_penyelesaian.destroy', $b->id_bukti)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/bukti_penyelesaian/index.blade.php ENDPATH**/ ?>