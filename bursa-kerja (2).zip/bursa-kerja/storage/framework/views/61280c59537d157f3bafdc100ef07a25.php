<!DOCTYPE html>
<html>
<head><title>Edit Lamaran</title></head>
<body>
    <h1>Edit Lamaran</h1>
    <?php if($errors->any()): ?><div style="color: red;"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <form action="<?php echo e(route('lamaran.update', $lamaran->id_lamaran)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <label>Pekerjaan:</label><br>
        <select name="id_pekerjaan">
            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id_pekerjaan); ?>" <?php echo e($lamaran->id_pekerjaan == $p->id_pekerjaan ? 'selected' : ''); ?>><?php echo e($p->deskripsi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Pencari Kerja:</label><br>
        <select name="id_pencari">
            <?php $__currentLoopData = $pencariKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pk->id_pencari); ?>" <?php echo e($lamaran->id_pencari == $pk->id_pencari ? 'selected' : ''); ?>><?php echo e($pk->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Status Lamaran:</label><br>
        <select name="status_lamaran">
            <option value="menunggu" <?php echo e($lamaran->status_lamaran == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
            <option value="diterima" <?php echo e($lamaran->status_lamaran == 'diterima' ? 'selected' : ''); ?>>Diterima</option>
            <option value="ditolak" <?php echo e($lamaran->status_lamaran == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select><br><br>
        <label>Tanggal Submit:</label><br>
        <input type="date" name="tanggal_submit" value="<?php echo e(old('tanggal_submit', $lamaran->tanggal_submit)); ?>"><br><br>
        <button type="submit">Update</button>
    </form>
    <br><a href="<?php echo e(route('lamaran.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/lamaran/edit.blade.php ENDPATH**/ ?>