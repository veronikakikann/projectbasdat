<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pencari Kerja</title>
</head>
<body>
    <h1>Tambah Pencari Kerja</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pencari_kerja.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>NIK:</label><br>
        <input type="text" name="nik" value="<?php echo e(old('nik')); ?>"><br><br>

        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?php echo e(old('nama')); ?>"><br><br>

        <label>Alamat:</label><br>
        <textarea name="alamat"><?php echo e(old('alamat')); ?></textarea><br><br>

        <label>No. Telpon:</label><br>
        <input type="text" name="no_telpon" value="<?php echo e(old('no_telpon')); ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo e(old('email')); ?>"><br><br>

        <label>Password:</label><br>
        <input type="password" name="password"><br><br>

        <label>Latitude:</label><br>
        <input type="text" name="latitude" value="<?php echo e(old('latitude')); ?>"><br><br>

        <label>Longitude:</label><br>
        <input type="text" name="longitude" value="<?php echo e(old('longitude')); ?>"><br><br>

        <label>Status Verifikasi:</label><br>
        <select name="status_verifikasi">
            <option value="menunggu" <?php echo e(old('status_verifikasi') == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
            <option value="terverifikasi" <?php echo e(old('status_verifikasi') == 'terverifikasi' ? 'selected' : ''); ?>>Terverifikasi</option>
            <option value="ditolak" <?php echo e(old('status_verifikasi') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select><br><br>

        <label>Diverifikasi Oleh Admin:</label><br>
        <select name="id_admin">
            <option value="">-- Belum ada --</option>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($admin->id_admin); ?>" <?php echo e(old('id_admin') == $admin->id_admin ? 'selected' : ''); ?>><?php echo e($admin->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label>Tanggal Daftar:</label><br>
        <input type="date" name="tanggal_daftar" value="<?php echo e(old('tanggal_daftar')); ?>"><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('pencari_kerja.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/pencari_kerja/create.blade.php ENDPATH**/ ?>