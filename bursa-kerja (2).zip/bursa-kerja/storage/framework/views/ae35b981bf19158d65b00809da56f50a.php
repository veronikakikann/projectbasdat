<!DOCTYPE html>
<html>
<head><title>Data Notifikasi</title></head>
<body>
    <h1>Data Notifikasi</h1>
    <?php if(session('success')): ?><p style="color: green;"><?php echo e(session('success')); ?></p><?php endif; ?>
    <a href="<?php echo e(route('notifikasi.create')); ?>">Tambah Notifikasi</a>
    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr><th>ID</th><th>ID User</th><th>Tipe User</th><th>Isi Pesan</th><th>Status Baca</th><th>Tanggal</th><th>Aksi</th></tr>
        <?php $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($n->id_notifikasi); ?></td>
            <td><?php echo e($n->id_user); ?></td>
            <td><?php echo e($n->tipe_user); ?></td>
            <td><?php echo e($n->isi_pesan); ?></td>
            <td><?php echo e($n->status_baca ? 'Sudah dibaca' : 'Belum dibaca'); ?></td>
            <td><?php echo e($n->tanggal); ?></td>
            <td>
                <a href="<?php echo e(route('notifikasi.edit', $n->id_notifikasi)); ?>">Edit</a>
                <form action="<?php echo e(route('notifikasi.destroy', $n->id_notifikasi)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/notifikasi/index.blade.php ENDPATH**/ ?>