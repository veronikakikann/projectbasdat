<!DOCTYPE html>
<html>
<head>
    <title>Data Keahlian Pencari Kerja</title>
</head>
<body>
    <h1>Data Keahlian Pencari Kerja</h1>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <a href="<?php echo e(route('keahlian_pencari_kerja.create')); ?>">Tambah Data</a>

    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr>
            <th>Pencari Kerja</th>
            <th>Keahlian</th>
            <th>File Rekomendasi</th>
            <th>Status Verifikasi</th>
            <th>Tanggal Upload</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($d->nama_pencari); ?></td>
            <td><?php echo e($d->nama_keahlian); ?></td>
            <td><?php echo e($d->file_surat_rekomendasi); ?></td>
            <td><?php echo e($d->status_verifikasi_keahlian); ?></td>
            <td><?php echo e($d->tanggal_upload); ?></td>
            <td>
                <a href="<?php echo e(route('keahlian_pencari_kerja.edit', [$d->id_pencari, $d->id_keahlian])); ?>">Edit</a>
                <form action="<?php echo e(route('keahlian_pencari_kerja.destroy', [$d->id_pencari, $d->id_keahlian])); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/keahlian_pencari_kerja/index.blade.php ENDPATH**/ ?>