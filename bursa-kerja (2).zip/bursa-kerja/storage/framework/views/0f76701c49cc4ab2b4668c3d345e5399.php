<!DOCTYPE html>
<html>
<head><title>Data Rating</title></head>
<body>
    <h1>Data Rating</h1>
    <?php if(session('success')): ?><p style="color: green;"><?php echo e(session('success')); ?></p><?php endif; ?>
    <a href="<?php echo e(route('rating.create')); ?>">Tambah Rating</a>
    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr><th>ID</th><th>Lamaran</th><th>Pemberi (ID)</th><th>Penerima (ID)</th><th>Arah</th><th>Skor</th><th>Kategori</th><th>Tanggal</th><th>Aksi</th></tr>
        <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($r->id_rating); ?></td>
            <td><?php echo e($r->id_lamaran); ?></td>
            <td><?php echo e($r->pemberi_rating); ?></td>
            <td><?php echo e($r->penerima_rating); ?></td>
            <td><?php echo e($r->arah_rating); ?></td>
            <td><?php echo e($r->skor); ?></td>
            <td><?php echo e($r->kategori_komentar); ?></td>
            <td><?php echo e($r->tanggal_rating); ?></td>
            <td>
                <a href="<?php echo e(route('rating.edit', $r->id_rating)); ?>">Edit</a>
                <form action="<?php echo e(route('rating.destroy', $r->id_rating)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/rating/index.blade.php ENDPATH**/ ?>