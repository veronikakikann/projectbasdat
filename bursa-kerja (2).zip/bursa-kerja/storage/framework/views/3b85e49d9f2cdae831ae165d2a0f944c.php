<!DOCTYPE html>
<html>
<head><title>Tambah Lamaran</title></head>
<body>
    <h1>Tambah Lamaran</h1>
    <?php if($errors->any()): ?><div style="color: red;"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <form action="<?php echo e(route('lamaran.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Pekerjaan:</label><br>
        <select name="id_pekerjaan">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id_pekerjaan); ?>" <?php echo e(old('id_pekerjaan') == $p->id_pekerjaan ? 'selected' : ''); ?>><?php echo e($p->deskripsi); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Pencari Kerja:</label><br>
        <select name="id_pencari">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $pencariKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pk->id_pencari); ?>" <?php echo e(old('id_pencari') == $pk->id_pencari ? 'selected' : ''); ?>><?php echo e($pk->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Status Lamaran:</label><br>
        <select name="status_lamaran">
            <option value="menunggu" <?php echo e(old('status_lamaran') == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
            <option value="diterima" <?php echo e(old('status_lamaran') == 'diterima' ? 'selected' : ''); ?>>Diterima</option>
            <option value="ditolak" <?php echo e(old('status_lamaran') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select><br><br>
        <label>Tanggal Submit:</label><br>
        <input type="date" name="tanggal_submit" value="<?php echo e(old('tanggal_submit')); ?>"><br><br>
        <button type="submit">Simpan</button>
    </form>
    <br><a href="<?php echo e(route('lamaran.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/lamaran/create.blade.php ENDPATH**/ ?>