<!DOCTYPE html>
<html>
<head>
    <title>Tambah Keahlian</title>
</head>
<body>
    <h1>Tambah Keahlian</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('keahlian.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Nama Keahlian:</label><br>
        <input type="text" name="nama_keahlian" value="<?php echo e(old('nama_keahlian')); ?>"><br><br>

        <label>Deskripsi:</label><br>
        <textarea name="deskripsi"><?php echo e(old('deskripsi')); ?></textarea><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('keahlian.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/keahlian/create.blade.php ENDPATH**/ ?>