<!DOCTYPE html>
<html>
<head>
    <title>Edit Keahlian Pencari Kerja</title>
</head>
<body>
    <h1>Edit Keahlian Pencari Kerja</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/keahlian_pencari_kerja/edit.blade.php ENDPATH**/ ?>