<!DOCTYPE html>
<html>
<head><title>Data Lamaran</title></head>
<body>
    <h1>Data Lamaran</h1>
    <?php if(session('success')): ?><p style="color: green;"><?php echo e(session('success')); ?></p><?php endif; ?>
    <a href="<?php echo e(route('lamaran.create')); ?>">Tambah Lamaran</a>
    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr><th>ID</th><th>Pekerjaan</th><th>Pencari Kerja</th><th>Status</th><th>Tanggal Submit</th><th>Aksi</th></tr>
        <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($l->id_lamaran); ?></td>
            <td><?php echo e($l->pekerjaan->deskripsi ?? '-'); ?></td>
            <td><?php echo e($l->pencariKerja->nama ?? '-'); ?></td>
            <td><?php echo e($l->status_lamaran); ?></td>
            <td><?php echo e($l->tanggal_submit); ?></td>
            <td>
                <a href="<?php echo e(route('lamaran.edit', $l->id_lamaran)); ?>">Edit</a>
                <form action="<?php echo e(route('lamaran.destroy', $l->id_lamaran)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/lamaran/index.blade.php ENDPATH**/ ?>