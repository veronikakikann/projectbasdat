<!DOCTYPE html>
<html>
<head>
    <title>Data Pencari Kerja</title>
</head>
<body>
    <h1>Data Pencari Kerja</h1>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <a href="<?php echo e(route('pencari_kerja.create')); ?>">Tambah Pencari Kerja</a>

    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr>
            <th>ID</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Email</th>
            <th>No. Telpon</th>
            <th>Status Verifikasi</th>
            <th>Diverifikasi Oleh</th>
            <th>Tanggal Daftar</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $pencariKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($pk->id_pencari); ?></td>
            <td><?php echo e($pk->nik); ?></td>
            <td><?php echo e($pk->nama); ?></td>
            <td><?php echo e($pk->email); ?></td>
            <td><?php echo e($pk->no_telpon); ?></td>
            <td><?php echo e($pk->status_verifikasi); ?></td>
            <td><?php echo e($pk->admin->nama ?? '-'); ?></td>
            <td><?php echo e($pk->tanggal_daftar); ?></td>
            <td>
                <a href="<?php echo e(route('pencari_kerja.edit', $pk->id_pencari)); ?>">Edit</a>
                <form action="<?php echo e(route('pencari_kerja.destroy', $pk->id_pencari)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/pencari_kerja/index.blade.php ENDPATH**/ ?>