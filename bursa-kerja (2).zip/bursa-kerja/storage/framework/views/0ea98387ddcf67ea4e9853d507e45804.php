<!DOCTYPE html>
<html>
<head><title>Tambah Bukti Penyelesaian</title></head>
<body>
    <h1>Tambah Bukti Penyelesaian</h1>
    <?php if($errors->any()): ?><div style="color: red;"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <form action="<?php echo e(route('bukti_penyelesaian.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Lamaran:</label><br>
        <select name="id_lamaran">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $lamaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($l->id_lamaran); ?>" <?php echo e(old('id_lamaran') == $l->id_lamaran ? 'selected' : ''); ?>>Lamaran #<?php echo e($l->id_lamaran); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <label>Foto Bukti Kerja:</label><br>
        <input type="text" name="foto_bukti_kerja" value="<?php echo e(old('foto_bukti_kerja')); ?>" placeholder="nama_file.jpg"><br><br>
        <label>Foto Bukti Bayar:</label><br>
        <input type="text" name="foto_bukti_bayar" value="<?php echo e(old('foto_bukti_bayar')); ?>" placeholder="nama_file.jpg"><br><br>
        <label>Catatan:</label><br>
        <textarea name="catatan"><?php echo e(old('catatan')); ?></textarea><br><br>
        <label>Tanggal Upload:</label><br>
        <input type="date" name="tanggal_upload" value="<?php echo e(old('tanggal_upload')); ?>"><br><br>
        <button type="submit">Simpan</button>
    </form>
    <br><a href="<?php echo e(route('bukti_penyelesaian.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/bukti_penyelesaian/create.blade.php ENDPATH**/ ?>