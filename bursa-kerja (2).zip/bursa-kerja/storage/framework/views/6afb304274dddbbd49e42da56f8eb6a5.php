<!DOCTYPE html>
<html>
<head>
    <title>Tambah Admin</title>
</head>
<body>
    <h1>Tambah Admin</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?php echo e(old('nama')); ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo e(old('email')); ?>"><br><br>

        <label>Password:</label><br>
        <input type="password" name="password"><br><br>

        <label>Tanggal Bergabung:</label><br>
        <input type="date" name="tanggal_bergabung" value="<?php echo e(old('tanggal_bergabung')); ?>"><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('admin.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/admin/create.blade.php ENDPATH**/ ?>