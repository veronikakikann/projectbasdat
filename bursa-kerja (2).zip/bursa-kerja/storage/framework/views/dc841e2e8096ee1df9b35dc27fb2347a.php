<!DOCTYPE html>
<html>
<head><title>Tambah Notifikasi</title></head>
<body>
    <h1>Tambah Notifikasi</h1>
    <?php if($errors->any()): ?><div style="color: red;"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
    <form action="<?php echo e(route('notifikasi.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>ID User:</label><br>
        <input type="number" name="id_user" value="<?php echo e(old('id_user')); ?>"><br><br>
        <label>Tipe User:</label><br>
        <select name="tipe_user">
            <option value="pencari_kerja" <?php echo e(old('tipe_user') == 'pencari_kerja' ? 'selected' : ''); ?>>Pencari Kerja</option>
            <option value="pemberi_kerja" <?php echo e(old('tipe_user') == 'pemberi_kerja' ? 'selected' : ''); ?>>Pemberi Kerja</option>
        </select><br><br>
        <label>Isi Pesan:</label><br>
        <textarea name="isi_pesan"><?php echo e(old('isi_pesan')); ?></textarea><br><br>
        <label>Status Baca:</label><br>
        <select name="status_baca">
            <option value="0">Belum dibaca</option>
            <option value="1">Sudah dibaca</option>
        </select><br><br>
        <label>Tanggal:</label><br>
        <input type="datetime-local" name="tanggal" value="<?php echo e(old('tanggal')); ?>"><br><br>
        <button type="submit">Simpan</button>
    </form>
    <br><a href="<?php echo e(route('notifikasi.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/notifikasi/create.blade.php ENDPATH**/ ?>