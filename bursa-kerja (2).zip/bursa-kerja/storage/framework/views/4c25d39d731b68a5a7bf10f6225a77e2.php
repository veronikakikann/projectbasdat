<!DOCTYPE html>
<html>
<head>
    <title>Data Keahlian</title>
</head>
<body>
    <h1>Data Keahlian</h1>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <a href="<?php echo e(route('keahlian.create')); ?>">Tambah Keahlian</a>

    <table border="1" cellpadding="8" style="border-collapse: collapse; margin-top: 10px;">
        <tr>
            <th>ID</th>
            <th>Nama Keahlian</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = $keahlian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($k->id_keahlian); ?></td>
            <td><?php echo e($k->nama_keahlian); ?></td>
            <td><?php echo e($k->deskripsi); ?></td>
            <td>
                <a href="<?php echo e(route('keahlian.edit', $k->id_keahlian)); ?>">Edit</a>
                <form action="<?php echo e(route('keahlian.destroy', $k->id_keahlian)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Yakin hapus?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/keahlian/index.blade.php ENDPATH**/ ?>