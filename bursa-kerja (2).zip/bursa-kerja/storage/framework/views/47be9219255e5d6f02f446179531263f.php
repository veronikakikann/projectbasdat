<!DOCTYPE html>
<html>
<head>
    <title>Tambah Keahlian Pencari Kerja</title>
</head>
<body>
    <h1>Tambah Keahlian Pencari Kerja</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('keahlian_pencari_kerja.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Pencari Kerja:</label><br>
        <select name="id_pencari">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $pencariKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pk->id_pencari); ?>" <?php echo e(old('id_pencari') == $pk->id_pencari ? 'selected' : ''); ?>><?php echo e($pk->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label>Keahlian:</label><br>
        <select name="id_keahlian">
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $keahlian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id_keahlian); ?>" <?php echo e(old('id_keahlian') == $k->id_keahlian ? 'selected' : ''); ?>><?php echo e($k->nama_keahlian); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label>File Surat Rekomendasi:</label><br>
        <input type="text" name="file_surat_rekomendasi" value="<?php echo e(old('file_surat_rekomendasi')); ?>" placeholder="nama_file.pdf"><br><br>

        <label>Status Verifikasi Keahlian:</label><br>
        <select name="status_verifikasi_keahlian">
            <option value="menunggu" <?php echo e(old('status_verifikasi_keahlian') == 'menunggu' ? 'selected' : ''); ?>>Menunggu</option>
            <option value="terverifikasi" <?php echo e(old('status_verifikasi_keahlian') == 'terverifikasi' ? 'selected' : ''); ?>>Terverifikasi</option>
            <option value="ditolak" <?php echo e(old('status_verifikasi_keahlian') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
        </select><br><br>

        <label>Tanggal Upload:</label><br>
        <input type="date" name="tanggal_upload" value="<?php echo e(old('tanggal_upload')); ?>"><br><br>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="<?php echo e(route('keahlian_pencari_kerja.index')); ?>">Kembali ke daftar</a>
</body>
</html><?php /**PATH C:\laragon\www\bursa-kerja\resources\views/keahlian_pencari_kerja/create.blade.php ENDPATH**/ ?>